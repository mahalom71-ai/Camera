# OpenLens Camera

A full-featured camera app for Android 5.0 (API 21) and newer, built on CameraX + Camera2 interop.

## Features

| Area | What you get |
|---|---|
| Photo | Tap-to-focus, long-press AE/AF lock, pinch zoom, exposure slider, flash (off/auto/on/torch), 3s/10s timer, burst (hold shutter), 4:3 and 16:9 |
| Video | Up to 4K (device dependent), quality picker, pause/resume, torch, record timer |
| HDR / Night / Portrait | Uses the phone maker's CameraX vendor extensions when available (Samsung, Google, Xiaomi, OnePlus, ...); falls back to the camera's HDR scene mode or low-noise + exposure-boost capture |
| Pro mode | Manual ISO, shutter speed (up to 2 s), manual focus, white-balance presets (when the device exposes manual sensor control) |
| Scan | Live QR / barcode scanner (ML Kit, works offline) with Open / Copy / Share |
| Composition | Grid (3x3, 4x4, golden ratio) and a live horizon level |
| Extras | Front-camera mirror option, geotagging, volume-key shutter, shutter sound, gallery thumbnail |

Photos and videos are saved to `DCIM/Camera` through MediaStore, so no storage permission is needed on Android 10+.

## Build

**Android Studio:** open this folder, let Gradle sync, press Run.

**Command line:** `gradle assembleDebug` (JDK 17, Android SDK 34). The APK lands in `app/build/outputs/apk/debug/`.

**No Android Studio?** Push the folder to a GitHub repo; the included workflow (`.github/workflows/build-apk.yml`) builds the APK and attaches it as a downloadable artifact.

## Notes

- Which modes are "real" depends on the phone: HDR/Night/Portrait extensions and Pro-mode ranges are reported by the device. Unsupported modes show a toast and fall back gracefully.
- RAW/DNG capture and multi-lens (ultra-wide/tele) switching beyond the zoom range the logical camera exposes are not included.
- Change `applicationId` in `app/build.gradle.kts` before publishing, and use your own signing key.
