package com.openlens.camera

import android.Manifest
import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.location.Location
import android.location.LocationManager
import android.media.MediaActionSound
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.OrientationEventListener
import android.view.Surface
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.UseCase
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.openlens.camera.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.pow
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    // ---------------------------------------------------------------- modes
    enum class Mode(val label: String) {
        PHOTO("Photo"),
        VIDEO("Video"),
        PORTRAIT("Portrait"),
        NIGHT("Night"),
        HDR("HDR"),
        PRO("Pro"),
        QR("Scan")
    }

    private lateinit var b: ActivityMainBinding
    private val mainExecutor by lazy { ContextCompat.getMainExecutor(this) }
    private val bgExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("camera_prefs", Context.MODE_PRIVATE) }
    private val sound by lazy { MediaActionSound() }

    // ---------------------------------------------------------------- camera state
    private var cameraProvider: ProcessCameraProvider? = null
    private var extensionsManager: ExtensionsManager? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var imageAnalysis: ImageAnalysis? = null
    private var recording: Recording? = null

    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var mode = Mode.PHOTO
    private var extActive = false
    private var modeNotice = false

    private var flashState = 0                 // 0 off, 1 auto, 2 on, 3 torch
    private var timerSeconds = 0               // 0 / 3 / 10
    private var aspect43 = true
    private var gridMode = 0
    private var countdown: CountDownTimer? = null
    private var burstActive = false
    private var minZoom = 1f
    private var maxZoom = 1f
    private var evLower = 0
    private var evStep = 0f
    private var paused = false

    private val modeViews = mutableMapOf<Mode, TextView>()
    private val hideEv = Runnable { b.exposurePanel.visibility = View.GONE }

    // ---------------------------------------------------------------- pro mode state
    private var isoRange: Range<Int>? = null
    private var expRange: Range<Long>? = null
    private var minFocusDiopter = 0f
    private var awbModes: List<Int> = listOf(CaptureRequest.CONTROL_AWB_MODE_AUTO)
    private var hdrSceneSupported = false
    private var proAutoExp = true
    private var proAutoFocus = true
    private var awbIndex = 0

    private val awbNames = mapOf(
        CaptureRequest.CONTROL_AWB_MODE_AUTO to "Auto",
        CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT to "Incandescent (tungsten)",
        CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT to "Fluorescent",
        CaptureRequest.CONTROL_AWB_MODE_WARM_FLUORESCENT to "Warm fluorescent",
        CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT to "Daylight",
        CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT to "Cloudy",
        CaptureRequest.CONTROL_AWB_MODE_TWILIGHT to "Twilight",
        CaptureRequest.CONTROL_AWB_MODE_SHADE to "Shade"
    )

    // ---------------------------------------------------------------- QR
    private val barcodeScanner by lazy {
        BarcodeScanning.getClient(
            BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS).build()
        )
    }
    private var lastQrValue: String? = null
    private var lastQrUrl: String? = null

    // ---------------------------------------------------------------- orientation
    private val orientationListener by lazy {
        object : OrientationEventListener(this) {
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == ORIENTATION_UNKNOWN) return
                val rotation = when (orientation) {
                    in 45..134 -> Surface.ROTATION_270
                    in 135..224 -> Surface.ROTATION_180
                    in 225..314 -> Surface.ROTATION_90
                    else -> Surface.ROTATION_0
                }
                imageCapture?.targetRotation = rotation
                videoCapture?.targetRotation = rotation
                imageAnalysis?.targetRotation = rotation
            }
        }
    }

    // ---------------------------------------------------------------- permissions
    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result[Manifest.permission.CAMERA] == true || hasPerm(Manifest.permission.CAMERA)) {
                startCamera()
            } else {
                toast("Camera permission is required. Enable it in system settings.")
            }
        }

    private val audioLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            // Record with audio if granted, otherwise silent video.
            startRecording()
        }

    private val locationLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (!granted) {
                prefs.edit().putBoolean("geotag", false).apply()
                toast("Location permission denied – geotag disabled")
            }
        }

    // ================================================================= lifecycle
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.ivThumb.clipToOutline = true
        b.ivThumb.outlineProvider = ViewOutlineProvider.BACKGROUND

        buildModeSelector()
        setupButtons()
        setupGestures()
        setupProPanel()
        applyPrefsToUi()
        updateTopLabels()
        updateShutterStyle()
        prefs.getString("last_uri", null)?.let { loadThumb(Uri.parse(it)) }

        if (hasPerm(Manifest.permission.CAMERA)) {
            startCamera()
        } else {
            val perms = mutableListOf(Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
                perms += Manifest.permission.WRITE_EXTERNAL_STORAGE
            }
            permissionLauncher.launch(perms.toTypedArray())
        }
    }

    override fun onResume() {
        super.onResume()
        orientationListener.enable()
        if (prefs.getBoolean("level", true)) b.levelView.start()
    }

    override fun onPause() {
        orientationListener.disable()
        b.levelView.stop()
        burstActive = false
        super.onPause()
    }

    override fun onDestroy() {
        countdown?.cancel()
        ui.removeCallbacksAndMessages(null)
        recording?.stop()
        bgExecutor.shutdown()
        barcodeScanner.close()
        sound.release()
        super.onDestroy()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (prefs.getBoolean("volume", true) &&
            (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)
        ) {
            if (event.repeatCount == 0) onShutter()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    // ================================================================= UI wiring
    private fun buildModeSelector() {
        for (m in Mode.values()) {
            val tv = TextView(this).apply {
                text = m.label.uppercase(Locale.US)
                textSize = 13f
                setPadding(dp(14), dp(10), dp(14), dp(10))
                setOnClickListener { setMode(m) }
            }
            b.modeContainer.addView(tv)
            modeViews[m] = tv
        }
        refreshModeStyles()
    }

    private fun refreshModeStyles() {
        for ((m, tv) in modeViews) {
            val sel = m == mode
            tv.setTextColor(if (sel) Color.parseColor("#FFD54F") else Color.WHITE)
            tv.setTypeface(null, if (sel) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
        }
    }

    private fun setMode(m: Mode) {
        if (recording != null || m == mode) return
        cancelCountdown()
        mode = m
        modeNotice = true
        refreshModeStyles()
        modeViews[m]?.let { tv ->
            b.modeScroll.post {
                b.modeScroll.smoothScrollTo(tv.left - (b.modeScroll.width - tv.width) / 2, 0)
            }
        }
        b.proPanel.visibility = if (m == Mode.PRO) View.VISIBLE else View.GONE
        b.qrCard.visibility = View.GONE
        b.exposurePanel.visibility = View.GONE
        updateShutterStyle()
        updateTopLabels()
        bindCamera()
    }

    private fun setupButtons() {
        b.shutterFrame.setOnClickListener { onShutter() }
        b.shutterFrame.setOnLongClickListener {
            if (recording == null && (mode == Mode.PHOTO || mode == Mode.PRO)) {
                burstActive = true
                burstShot(0)
                true
            } else false
        }
        b.shutterFrame.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_UP || ev.action == MotionEvent.ACTION_CANCEL) {
                burstActive = false
            }
            false
        }

        b.btnSwitch.setOnClickListener {
            if (recording != null) return@setOnClickListener
            lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
                CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
            bindCamera()
        }

        b.btnFlash.setOnClickListener {
            if (camera?.cameraInfo?.hasFlashUnit() != true) {
                toast("This camera has no flash")
                return@setOnClickListener
            }
            flashState = (flashState + 1) % 4
            applyFlash()
        }

        b.btnTimer.setOnClickListener {
            timerSeconds = when (timerSeconds) { 0 -> 3; 3 -> 10; else -> 0 }
            updateTopLabels()
        }

        b.btnRatio.setOnClickListener {
            if (mode == Mode.VIDEO) return@setOnClickListener
            aspect43 = !aspect43
            updateTopLabels()
            bindCamera()
        }

        b.btnGrid.setOnClickListener {
            gridMode = (gridMode + 1) % 4
            b.gridView.mode = gridMode
            updateTopLabels()
        }

        b.btnSettings.setOnClickListener { showSettings() }

        b.tvZoom.setOnClickListener { cycleZoom() }

        b.btnPause.setOnClickListener {
            val rec = recording ?: return@setOnClickListener
            paused = !paused
            if (paused) rec.pause() else rec.resume()
            b.btnPause.text = if (paused) ">" else "II"
        }

        b.ivThumb.setOnClickListener { openLastMedia() }

        b.qrCard.setOnClickListener { showQrActions() }

        b.seekEv.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val idx = progress + evLower
                camera?.cameraControl?.setExposureCompensationIndex(idx)
                b.tvEvLabel.text = String.format(Locale.US, "EV %+.1f", idx * evStep)
                scheduleHideEv()
            }

            override fun onStartTrackingTouch(sb: SeekBar) = Unit
            override fun onStopTrackingTouch(sb: SeekBar) = Unit
        })
    }

    private fun setupGestures() {
        val scale = android.view.ScaleGestureDetector(
            this,
            object : android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(d: android.view.ScaleGestureDetector): Boolean {
                    val cam = camera ?: return true
                    val cur = cam.cameraInfo.zoomState.value?.zoomRatio ?: 1f
                    val target = (cur * d.scaleFactor).coerceIn(minZoom, maxZoom)
                    cam.cameraControl.setZoomRatio(target)
                    return true
                }
            })
        val tap = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                focusAt(e.x, e.y, lock = false)
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                focusAt(e.x, e.y, lock = true)
            }
        })
        b.viewFinder.setOnTouchListener { v, ev ->
            scale.onTouchEvent(ev)
            if (!scale.isInProgress) tap.onTouchEvent(ev)
            if (ev.action == MotionEvent.ACTION_UP) v.performClick()
            true
        }
    }

    private fun applyPrefsToUi() {
        b.levelView.visibility = if (prefs.getBoolean("level", true)) View.VISIBLE else View.GONE
        if (prefs.getBoolean("level", true)) b.levelView.start() else b.levelView.stop()
    }

    private fun updateTopLabels() {
        b.btnTimer.text = if (timerSeconds == 0) "TIMER OFF" else "TIMER ${timerSeconds}S"
        b.btnRatio.text = if (mode == Mode.VIDEO) "16:9" else if (aspect43) "4:3" else "16:9"
        b.btnGrid.text = when (gridMode) {
            1 -> "GRID 3x3"; 2 -> "GRID 4x4"; 3 -> "GOLDEN"; else -> "GRID OFF"
        }
        b.btnRatio.alpha = if (mode == Mode.VIDEO) 0.5f else 1f
    }

    private fun updateShutterStyle() {
        val inner = b.shutterInner.background.mutate() as GradientDrawable
        inner.setColor(if (mode == Mode.VIDEO) Color.parseColor("#E53935") else Color.WHITE)
        val s = if (recording != null) 0.55f else 1f
        b.shutterInner.animate().scaleX(s).scaleY(s).setDuration(150).start()
        b.shutterFrame.alpha = if (mode == Mode.QR) 0.3f else 1f
    }

    // ================================================================= camera binding
    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = try { future.get() } catch (e: Exception) {
                toast("Could not open the camera: ${e.message}")
                return@addListener
            }
            cameraProvider = provider
            val extFuture = ExtensionsManager.getInstanceAsync(this, provider)
            extFuture.addListener({
                extensionsManager = try { extFuture.get() } catch (e: Exception) { null }
                bindCamera()
            }, mainExecutor)
        }, mainExecutor)
    }

    private fun extCandidates(m: Mode): List<Int> = when (m) {
        Mode.HDR -> listOf(ExtensionMode.HDR)
        Mode.NIGHT -> listOf(ExtensionMode.NIGHT)
        Mode.PORTRAIT -> listOf(ExtensionMode.BOKEH, ExtensionMode.FACE_RETOUCH)
        else -> emptyList()
    }

    private fun bindCamera() {
        val provider = cameraProvider ?: return
        if (recording != null) return

        camera?.cameraInfo?.zoomState?.removeObservers(this)
        provider.unbindAll()
        camera = null

        var base = CameraSelector.Builder().requireLensFacing(lensFacing).build()
        val hasLens = try { provider.hasCamera(base) } catch (e: Exception) { false }
        if (!hasLens) {
            lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
                CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
            base = CameraSelector.Builder().requireLensFacing(lensFacing).build()
            val other = try { provider.hasCamera(base) } catch (e: Exception) { false }
            if (!other) {
                toast("No camera found on this device")
                return
            }
        }

        // Vendor extension (HDR / Night / Portrait) if the device offers one.
        var extSelector: CameraSelector? = null
        val em = extensionsManager
        if (em != null) {
            for (ext in extCandidates(mode)) {
                try {
                    if (em.isExtensionAvailable(base, ext)) {
                        extSelector = em.getExtensionEnabledCameraSelector(base, ext)
                        break
                    }
                } catch (e: Exception) { /* try next */ }
            }
        }

        val use43 = aspect43 && mode != Mode.VIDEO
        val ratioStrategy = AspectRatioStrategy(
            if (use43) AspectRatio.RATIO_4_3 else AspectRatio.RATIO_16_9,
            AspectRatioStrategy.FALLBACK_RULE_AUTO
        )
        val rs = ResolutionSelector.Builder().setAspectRatioStrategy(ratioStrategy).build()

        // Make the on-screen viewfinder match the capture aspect ratio.
        val lp = b.previewContainer.layoutParams as ConstraintLayout.LayoutParams
        val wanted = if (use43) "H,3:4" else "H,9:16"
        if (lp.dimensionRatio != wanted) {
            lp.dimensionRatio = wanted
            b.previewContainer.layoutParams = lp
        }

        val preview = Preview.Builder().setResolutionSelector(rs).build()
        preview.setSurfaceProvider(b.viewFinder.surfaceProvider)

        imageCapture = null
        videoCapture = null
        imageAnalysis = null
        val useCases = mutableListOf<UseCase>(preview)

        when (mode) {
            Mode.VIDEO -> {
                val q = selectedQuality()
                val recorder = Recorder.Builder()
                    .setQualitySelector(
                        QualitySelector.from(q, FallbackStrategy.lowerQualityOrHigherThan(q))
                    )
                    .build()
                videoCapture = VideoCapture.withOutput(recorder)
                useCases += videoCapture!!
            }
            Mode.QR -> {
                val analysisRs = ResolutionSelector.Builder()
                    .setAspectRatioStrategy(ratioStrategy)
                    .setResolutionStrategy(
                        ResolutionStrategy(
                            Size(1280, 960),
                            ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER
                        )
                    )
                    .build()
                val analysis = ImageAnalysis.Builder()
                    .setResolutionSelector(analysisRs)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(bgExecutor) { proxy -> analyzeFrame(proxy) }
                imageAnalysis = analysis
                useCases += analysis
            }
            else -> {
                imageCapture = ImageCapture.Builder()
                    .setResolutionSelector(rs)
                    .setCaptureMode(
                        if (prefs.getBoolean("maxq", false))
                            ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY
                        else ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY
                    )
                    .setJpegQuality(95)
                    .build()
                useCases += imageCapture!!
            }
        }

        val attempts = if (extSelector != null) listOf(extSelector, base) else listOf(base)
        var bound = false
        for (sel in attempts) {
            try {
                camera = provider.bindToLifecycle(this, sel, *useCases.toTypedArray())
                extActive = sel !== base
                bound = true
                break
            } catch (e: Exception) {
                provider.unbindAll()
            }
        }
        if (!bound) {
            toast("This mode is not supported on this device")
            return
        }
        onCameraBound()
    }

    private fun onCameraBound() {
        val cam = camera ?: return

        // Zoom
        cam.cameraInfo.zoomState.observe(this) { s ->
            minZoom = s.minZoomRatio
            maxZoom = s.maxZoomRatio
            b.tvZoom.text = String.format(Locale.US, "%.1fx", s.zoomRatio)
        }

        // Exposure compensation
        val es = cam.cameraInfo.exposureState
        if (es.isExposureCompensationSupported) {
            val r = es.exposureCompensationRange
            evLower = r.lower
            evStep = es.exposureCompensationStep.toFloat()
            b.seekEv.max = r.upper - r.lower
            b.seekEv.progress = es.exposureCompensationIndex - r.lower
            b.tvEvLabel.text = String.format(Locale.US, "EV %+.1f", es.exposureCompensationIndex * evStep)
            b.seekEv.isEnabled = true
        } else {
            b.seekEv.isEnabled = false
        }

        loadCameraCaps()
        applyFlash()
        applyCamera2Options()

        // Basic night boost when the device has no vendor night mode.
        if (mode == Mode.NIGHT && !extActive && es.isExposureCompensationSupported) {
            val idx = (es.exposureCompensationRange.upper * 2) / 3
            cam.cameraControl.setExposureCompensationIndex(idx)
            b.seekEv.progress = idx - evLower
        }

        if (modeNotice) {
            modeNotice = false
            when (mode) {
                Mode.HDR -> if (!extActive) toast(
                    if (hdrSceneSupported) "Using the camera's built-in HDR scene mode"
                    else "HDR+ isn't supported by this camera – standard capture"
                )
                Mode.NIGHT -> if (!extActive) toast("No vendor night mode – using low-noise capture with exposure boost")
                Mode.PORTRAIT -> if (!extActive) toast("Portrait blur isn't supported by this camera – standard capture")
                Mode.QR -> toast("Point the camera at a QR code or barcode")
                else -> Unit
            }
        }
    }

    // ================================================================= camera2 helpers
    private fun loadCameraCaps() {
        val cam = camera ?: return
        val info = Camera2CameraInfo.from(cam.cameraInfo)
        isoRange = info.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        expRange = info.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
        minFocusDiopter =
            info.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        val awb = info.getCameraCharacteristic(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES)
        val list = awbNames.keys.filter { awb?.contains(it) == true }
        awbModes = if (list.isEmpty()) listOf(CaptureRequest.CONTROL_AWB_MODE_AUTO) else list
        val scenes = info.getCameraCharacteristic(CameraCharacteristics.CONTROL_AVAILABLE_SCENE_MODES)
        hdrSceneSupported = scenes?.contains(CaptureRequest.CONTROL_SCENE_MODE_HDR) == true

        // refresh the Pro UI for this lens
        val awbLabels = awbModes.map { awbNames[it] ?: "Mode $it" }
        b.spWb.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, awbLabels)
        awbIndex = awbIndex.coerceIn(0, awbModes.size - 1)
        b.spWb.setSelection(awbIndex)
        b.chkAutoExp.isEnabled = isoRange != null && expRange != null
        b.chkAutoFocus.isEnabled = minFocusDiopter > 0f
        if (!b.chkAutoExp.isEnabled) { proAutoExp = true; b.chkAutoExp.isChecked = true }
        if (!b.chkAutoFocus.isEnabled) { proAutoFocus = true; b.chkAutoFocus.isChecked = true }
        updateProLabels()
    }

    private fun applyCamera2Options() {
        val cam = camera ?: return
        val ctl = Camera2CameraControl.from(cam.cameraControl)
        val ob = CaptureRequestOptions.Builder()
        var any = false
        when (mode) {
            Mode.PRO -> {
                any = true
                if (!proAutoExp) {
                    ob.setCaptureRequestOption(
                        CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF
                    )
                    ob.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, isoValue())
                    ob.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, shutterNs())
                }
                if (!proAutoFocus) {
                    ob.setCaptureRequestOption(
                        CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF
                    )
                    ob.setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, focusDiopter())
                }
                ob.setCaptureRequestOption(
                    CaptureRequest.CONTROL_AWB_MODE, awbModes[awbIndex.coerceIn(0, awbModes.size - 1)]
                )
            }
            Mode.HDR -> if (!extActive && hdrSceneSupported) {
                any = true
                ob.setCaptureRequestOption(
                    CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_USE_SCENE_MODE
                )
                ob.setCaptureRequestOption(
                    CaptureRequest.CONTROL_SCENE_MODE, CaptureRequest.CONTROL_SCENE_MODE_HDR
                )
            }
            Mode.NIGHT -> if (!extActive) {
                any = true
                ob.setCaptureRequestOption(
                    CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY
                )
                ob.setCaptureRequestOption(
                    CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_HIGH_QUALITY
                )
            }
            else -> Unit
        }
        if (any) ctl.setCaptureRequestOptions(ob.build()) else ctl.clearCaptureRequestOptions()
    }

    // ---- Pro value mapping (log scale) ----
    private fun isoValue(): Int {
        val r = isoRange ?: return 100
        val p = b.seekIso.progress / 1000.0
        return (r.lower * (r.upper.toDouble() / r.lower).pow(p)).roundToInt().coerceIn(r.lower, r.upper)
    }

    private fun shutterNs(): Long {
        val r = expRange ?: return 10_000_000L
        val upper = minOf(r.upper, 2_000_000_000L)       // cap at 2 s so the preview stays usable
        val lower = maxOf(r.lower, 1L)
        val p = b.seekShutter.progress / 1000.0
        return (lower * (upper.toDouble() / lower).pow(p)).toLong().coerceIn(lower, upper)
    }

    private fun focusDiopter(): Float = minFocusDiopter * (b.seekFocus.progress / 1000f)

    private fun fmtShutter(ns: Long): String {
        val s = ns / 1e9
        return if (s >= 0.5) String.format(Locale.US, "%.1fs", s) else "1/${(1.0 / s).roundToInt()}"
    }

    private fun updateProLabels() {
        b.tvIso.text = if (proAutoExp) "ISO Auto" else "ISO ${isoValue()}"
        b.tvShutter.text = if (proAutoExp) "Shutter Auto" else "Shutter ${fmtShutter(shutterNs())}"
        b.tvFocus.text = if (proAutoFocus) "Focus Auto" else String.format(
            Locale.US, "Focus %.0f cm",
            if (focusDiopter() <= 0.01f) 999f else 100f / focusDiopter()
        )
        b.seekIso.isEnabled = !proAutoExp
        b.seekShutter.isEnabled = !proAutoExp
        b.seekFocus.isEnabled = !proAutoFocus
    }

    private fun setupProPanel() {
        val changed = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                updateProLabels()
                applyCamera2Options()
            }

            override fun onStartTrackingTouch(sb: SeekBar) = Unit
            override fun onStopTrackingTouch(sb: SeekBar) = Unit
        }
        b.seekIso.setOnSeekBarChangeListener(changed)
        b.seekShutter.setOnSeekBarChangeListener(changed)
        b.seekFocus.setOnSeekBarChangeListener(changed)
        b.seekIso.progress = 300
        b.seekShutter.progress = 600

        b.chkAutoExp.setOnCheckedChangeListener { _, checked ->
            proAutoExp = checked
            updateProLabels()
            applyCamera2Options()
        }
        b.chkAutoFocus.setOnCheckedChangeListener { _, checked ->
            proAutoFocus = checked
            updateProLabels()
            applyCamera2Options()
        }
        b.spWb.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos != awbIndex) {
                    awbIndex = pos
                    applyCamera2Options()
                }
            }

            override fun onNothingSelected(p: AdapterView<*>?) = Unit
        }
    }

    // ================================================================= flash / zoom / focus
    private fun applyFlash() {
        val cam = camera ?: return
        val has = cam.cameraInfo.hasFlashUnit()
        b.btnFlash.text = if (!has) "NO FLASH"
        else arrayOf("FLASH OFF", "FLASH AUTO", "FLASH ON", "TORCH")[flashState]
        if (!has) return
        imageCapture?.flashMode = when (flashState) {
            1 -> ImageCapture.FLASH_MODE_AUTO
            2 -> ImageCapture.FLASH_MODE_ON
            else -> ImageCapture.FLASH_MODE_OFF
        }
        val torch = flashState == 3 || (mode == Mode.VIDEO && flashState == 2)
        cam.cameraControl.enableTorch(torch)
    }

    private fun cycleZoom() {
        val cam = camera ?: return
        val cur = cam.cameraInfo.zoomState.value?.zoomRatio ?: 1f
        val stops = mutableListOf<Float>()
        if (minZoom < 0.95f) stops += minZoom
        stops += 1f
        for (z in listOf(2f, 5f, 10f)) if (z <= maxZoom) stops += z
        val next = stops.firstOrNull { it > cur + 0.05f } ?: stops.first()
        cam.cameraControl.setZoomRatio(next.coerceIn(minZoom, maxZoom))
    }

    private fun focusAt(x: Float, y: Float, lock: Boolean) {
        val cam = camera ?: return
        val point = b.viewFinder.meteringPointFactory.createPoint(x, y)
        var flags = FocusMeteringAction.FLAG_AWB
        val pro = mode == Mode.PRO
        if (!pro || proAutoFocus) flags = flags or FocusMeteringAction.FLAG_AF
        if (!pro || proAutoExp) flags = flags or FocusMeteringAction.FLAG_AE
        val builder = FocusMeteringAction.Builder(point, flags)
        if (lock) builder.disableAutoCancel() else builder.setAutoCancelDuration(4, TimeUnit.SECONDS)
        try {
            cam.cameraControl.startFocusAndMetering(builder.build())
        } catch (e: Exception) { /* ignore */ }
        showFocusRing(x, y, lock)
        if (lock) toast("AE/AF locked – tap to unlock")
        if (mode != Mode.QR && b.seekEv.isEnabled && !(pro && !proAutoExp)) {
            b.exposurePanel.visibility = View.VISIBLE
            scheduleHideEv()
        }
    }

    private fun scheduleHideEv() {
        ui.removeCallbacks(hideEv)
        ui.postDelayed(hideEv, 3500)
    }

    private fun showFocusRing(x: Float, y: Float, lock: Boolean) {
        val ring = b.focusRing
        val half = dp(36)
        ring.translationX = x - half
        ring.translationY = y - half
        ring.alpha = 1f
        ring.scaleX = 1.4f
        ring.scaleY = 1.4f
        ring.visibility = View.VISIBLE
        ring.animate().scaleX(1f).scaleY(1f).setDuration(180).withEndAction {
            ring.animate().alpha(0f).setStartDelay(if (lock) 1500 else 700).setDuration(300)
                .withEndAction { ring.visibility = View.INVISIBLE; ring.animate().setStartDelay(0) }
                .start()
        }.start()
    }

    // ================================================================= capture
    private fun onShutter() {
        when (mode) {
            Mode.QR -> toast("Just point the camera at a code – it scans automatically")
            Mode.VIDEO -> {
                if (recording != null) stopRecording()
                else if (countdown != null) cancelCountdown()
                else if (timerSeconds > 0) startCountdown { startRecording() }
                else startRecording()
            }
            else -> {
                if (countdown != null) cancelCountdown()
                else if (timerSeconds > 0) startCountdown { takePhoto() }
                else takePhoto()
            }
        }
    }

    private fun startCountdown(then: () -> Unit) {
        b.tvCountdown.visibility = View.VISIBLE
        countdown = object : CountDownTimer(timerSeconds * 1000L, 1000L) {
            override fun onTick(ms: Long) {
                b.tvCountdown.text = ((ms + 999) / 1000).toString()
            }

            override fun onFinish() {
                countdown = null
                b.tvCountdown.visibility = View.GONE
                then()
            }
        }.start()
    }

    private fun cancelCountdown() {
        countdown?.cancel()
        countdown = null
        b.tvCountdown.visibility = View.GONE
    }

    private fun burstShot(count: Int) {
        if (!burstActive || count >= 20) {
            burstActive = false
            return
        }
        takePhoto(silent = true) { burstShot(count + 1) }
    }

    private fun takePhoto(silent: Boolean = false, onDone: (() -> Unit)? = null) {
        val ic = imageCapture
        if (ic == null) {
            onDone?.invoke()
            return
        }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmssSSS", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_$stamp")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/Camera")
            }
        }
        val meta = ImageCapture.Metadata().apply {
            isReversedHorizontal =
                lensFacing == CameraSelector.LENS_FACING_FRONT && prefs.getBoolean("mirror", true)
            location = currentLocation()
        }
        val options = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ).setMetadata(meta).build()

        if (!silent && prefs.getBoolean("sound", true)) sound.play(MediaActionSound.SHUTTER_CLICK)
        flashScreen()

        ic.takePicture(options, mainExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                output.savedUri?.let { onMediaSaved(it) }
                onDone?.invoke()
            }

            override fun onError(exc: ImageCaptureException) {
                toast("Photo failed: ${exc.message}")
                burstActive = false
                onDone?.invoke()
            }
        })
    }

    private fun flashScreen() {
        b.flashOverlay.animate().cancel()
        b.flashOverlay.alpha = 0.7f
        b.flashOverlay.animate().alpha(0f).setDuration(160).start()
    }

    @SuppressLint("MissingPermission")
    private fun startRecording() {
        val vc = videoCapture ?: return
        if (recording != null) return
        val audioOk = hasPerm(Manifest.permission.RECORD_AUDIO)
        if (!audioOk && !prefs.getBoolean("audio_asked", false)) {
            prefs.edit().putBoolean("audio_asked", true).apply()
            audioLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }

        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "VID_$stamp")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/Camera")
            }
        }
        val output = MediaStoreOutputOptions.Builder(
            contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        var pending = vc.output.prepareRecording(this, output)
        if (audioOk) pending = pending.withAudioEnabled()

        if (prefs.getBoolean("sound", true)) sound.play(MediaActionSound.START_VIDEO_RECORDING)
        paused = false
        b.btnPause.text = "II"

        recording = pending.start(mainExecutor) { event ->
            when (event) {
                is VideoRecordEvent.Start -> {
                    b.tvRecTime.visibility = View.VISIBLE
                    b.tvRecTime.text = "00:00"
                    b.btnPause.visibility = View.VISIBLE
                    b.ivThumb.visibility = View.GONE
                    updateShutterStyle()
                }
                is VideoRecordEvent.Status -> {
                    val secs = TimeUnit.NANOSECONDS.toSeconds(event.recordingStats.recordedDurationNanos)
                    b.tvRecTime.text = String.format(Locale.US, "%02d:%02d", secs / 60, secs % 60)
                }
                is VideoRecordEvent.Finalize -> {
                    recording = null
                    b.tvRecTime.visibility = View.GONE
                    b.btnPause.visibility = View.GONE
                    b.ivThumb.visibility = View.VISIBLE
                    updateShutterStyle()
                    if (event.hasError()) {
                        toast("Video error (${event.error})")
                    } else {
                        onMediaSaved(event.outputResults.outputUri)
                    }
                }
                else -> Unit
            }
        }
    }

    private fun stopRecording() {
        if (prefs.getBoolean("sound", true)) sound.play(MediaActionSound.STOP_VIDEO_RECORDING)
        recording?.stop()
    }

    // ================================================================= QR
    private fun analyzeFrame(proxy: androidx.camera.core.ImageProxy) {
        val media = proxy.image
        if (media == null) {
            proxy.close()
            return
        }
        val input = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
        barcodeScanner.process(input)
            .addOnSuccessListener { codes ->
                val hit = codes.firstOrNull { !it.rawValue.isNullOrEmpty() }
                if (hit != null) showQr(hit)
            }
            .addOnCompleteListener { proxy.close() }
    }

    private fun showQr(code: Barcode) {
        val raw = code.rawValue ?: return
        if (raw == lastQrValue && b.qrCard.visibility == View.VISIBLE) return
        lastQrValue = raw
        lastQrUrl = when {
            code.valueType == Barcode.TYPE_URL && code.url?.url != null -> code.url?.url
            raw.startsWith("http://") || raw.startsWith("https://") -> raw
            else -> null
        }
        b.qrCard.text = raw
        b.qrCard.visibility = View.VISIBLE
    }

    private fun showQrActions() {
        val value = lastQrValue ?: return
        val url = lastQrUrl
        val items = mutableListOf<String>()
        if (url != null) items += "Open link"
        items += "Copy text"
        items += "Share"
        MaterialAlertDialogBuilder(this)
            .setTitle("Scanned code")
            .setMessage(value)
            .setItems(items.toTypedArray()) { _, which ->
                when (items[which]) {
                    "Open link" -> try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                    } catch (e: Exception) { toast("No app can open this link") }
                    "Copy text" -> {
                        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("code", value))
                        toast("Copied")
                    }
                    "Share" -> startActivity(
                        Intent.createChooser(
                            Intent(Intent.ACTION_SEND).setType("text/plain")
                                .putExtra(Intent.EXTRA_TEXT, value), "Share"
                        )
                    )
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ================================================================= settings
    private fun showSettings() {
        val labels = arrayOf(
            "Shutter sound",
            "Save location in photos (geotag)",
            "Mirror front-camera photos",
            "Volume keys take photo",
            "Horizon level",
            "Max quality photos (slower)"
        )
        val keys = arrayOf("sound", "geotag", "mirror", "volume", "level", "maxq")
        val defaults = booleanArrayOf(true, false, true, true, true, false)
        val checked = BooleanArray(keys.size) { prefs.getBoolean(keys[it], defaults[it]) }

        MaterialAlertDialogBuilder(this)
            .setTitle("Camera settings")
            .setMultiChoiceItems(labels, checked) { _, i, v -> checked[i] = v }
            .setPositiveButton("Save") { _, _ ->
                val e = prefs.edit()
                for (i in keys.indices) e.putBoolean(keys[i], checked[i])
                e.apply()
                if (checked[1] && !hasPerm(Manifest.permission.ACCESS_FINE_LOCATION)) {
                    locationLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                }
                applyPrefsToUi()
                bindCamera()
            }
            .setNeutralButton("Video quality…") { _, _ -> showVideoQuality() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun qualityLabel(q: Quality): String = when (q) {
        Quality.UHD -> "4K UHD"
        Quality.FHD -> "1080p Full HD"
        Quality.HD -> "720p HD"
        Quality.SD -> "480p SD"
        else -> q.toString()
    }

    private fun qualityKey(q: Quality): String = when (q) {
        Quality.UHD -> "UHD"
        Quality.FHD -> "FHD"
        Quality.HD -> "HD"
        else -> "SD"
    }

    private fun selectedQuality(): Quality = when (prefs.getString("vq", "FHD")) {
        "UHD" -> Quality.UHD
        "HD" -> Quality.HD
        "SD" -> Quality.SD
        else -> Quality.FHD
    }

    private fun showVideoQuality() {
        val provider = cameraProvider ?: return
        val sel = CameraSelector.Builder().requireLensFacing(lensFacing).build()
        val info = sel.filter(provider.availableCameraInfos).firstOrNull()
        val supported = if (info != null) QualitySelector.getSupportedQualities(info) else emptyList()
        if (supported.isEmpty()) {
            toast("No video qualities reported")
            return
        }
        val current = prefs.getString("vq", "FHD")
        val checkedIdx = supported.indexOfFirst { qualityKey(it) == current }.coerceAtLeast(0)
        MaterialAlertDialogBuilder(this)
            .setTitle("Video quality")
            .setSingleChoiceItems(
                supported.map { qualityLabel(it) }.toTypedArray(), checkedIdx
            ) { dialog, which ->
                prefs.edit().putString("vq", qualityKey(supported[which])).apply()
                dialog.dismiss()
                if (mode == Mode.VIDEO) bindCamera()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ================================================================= gallery / thumbnail
    private fun onMediaSaved(uri: Uri) {
        prefs.edit().putString("last_uri", uri.toString()).apply()
        loadThumb(uri)
    }

    private fun loadThumb(uri: Uri) {
        bgExecutor.execute {
            val bmp: Bitmap? = try {
                val type = contentResolver.getType(uri) ?: ""
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    contentResolver.loadThumbnail(uri, Size(220, 220), null)
                } else if (type.startsWith("video")) {
                    val r = MediaMetadataRetriever()
                    try {
                        r.setDataSource(this, uri)
                        r.getFrameAtTime(0)
                    } finally {
                        r.release()
                    }
                } else {
                    val opts = BitmapFactory.Options().apply { inSampleSize = 8 }
                    contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                }
            } catch (e: Exception) {
                null
            }
            if (bmp != null && !isDestroyed) runOnUiThread { b.ivThumb.setImageBitmap(bmp) }
        }
    }

    private fun openLastMedia() {
        val s = prefs.getString("last_uri", null)
        try {
            if (s != null) {
                val uri = Uri.parse(s)
                startActivity(
                    Intent(Intent.ACTION_VIEW)
                        .setDataAndType(uri, contentResolver.getType(uri))
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                )
            } else {
                startActivity(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY))
            }
        } catch (e: Exception) {
            toast("No gallery app found")
        }
    }

    // ================================================================= misc
    @SuppressLint("MissingPermission")
    private fun currentLocation(): Location? {
        if (!prefs.getBoolean("geotag", false)) return null
        if (!hasPerm(Manifest.permission.ACCESS_FINE_LOCATION)) return null
        return try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
                .mapNotNull { p -> if (lm.isProviderEnabled(p)) lm.getLastKnownLocation(p) else null }
                .maxByOrNull { it.time }
        } catch (e: Exception) {
            null
        }
    }

    private fun hasPerm(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
