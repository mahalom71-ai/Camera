package com.openlens.camera

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs
import kotlin.math.atan2

/** Composition grid: 0 = off, 1 = rule of thirds, 2 = 4x4, 3 = golden ratio. */
class GridOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var mode: Int = 0
        set(value) {
            field = value
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x99FFFFFF.toInt()
        strokeWidth = 2f
        style = Paint.Style.STROKE
    }

    override fun onDraw(canvas: Canvas) {
        val fractions: FloatArray = when (mode) {
            1 -> floatArrayOf(1f / 3f, 2f / 3f)
            2 -> floatArrayOf(0.25f, 0.5f, 0.75f)
            3 -> floatArrayOf(0.382f, 0.618f)
            else -> return
        }
        val w = width.toFloat()
        val h = height.toFloat()
        for (f in fractions) {
            canvas.drawLine(w * f, 0f, w * f, h, paint)
            canvas.drawLine(0f, h * f, w, h * f, paint)
        }
    }
}

/** Horizon level indicator driven by the accelerometer. Turns green when level. */
class LevelOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs), SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accel: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    private var roll = 0f
    private var flat = false
    private var running = false

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 4f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    fun start() {
        if (running || accel == null) return
        sensorManager.registerListener(this, accel, SensorManager.SENSOR_DELAY_UI)
        running = true
    }

    fun stop() {
        if (!running) return
        sensorManager.unregisterListener(this)
        running = false
    }

    override fun onSensorChanged(event: SensorEvent) {
        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]
        flat = abs(z) > 8.3f
        var r = Math.toDegrees(atan2(x.toDouble(), y.toDouble())).toFloat()
        while (r > 45f) r -= 90f
        while (r < -45f) r += 90f
        roll = roll * 0.8f + r * 0.2f
        invalidate()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onDraw(canvas: Canvas) {
        if (flat) return
        val cx = width / 2f
        val cy = height / 2f
        val half = width * 0.18f
        val level = abs(roll) < 1.2f
        paint.color = if (level) Color.parseColor("#66BB6A") else Color.WHITE
        // Fixed reference ticks
        canvas.drawLine(cx - half - 40f, cy, cx - half - 10f, cy, paint)
        canvas.drawLine(cx + half + 10f, cy, cx + half + 40f, cy, paint)
        // Tilting horizon line
        canvas.save()
        canvas.rotate(roll, cx, cy)
        canvas.drawLine(cx - half, cy, cx + half, cy, paint)
        canvas.restore()
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }
}
